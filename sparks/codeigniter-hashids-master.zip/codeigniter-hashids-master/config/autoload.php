<?php

/**
 * @author 		Jason M Horwitz <jason@sekati.com>
 * @copyright	Copyright (c) 2013, Sekati.com
 * @license		http://www.opensource.org/licenses/mit-license.php
 */

$autoload['config'] = array('hashids');
$autoload['helper'] = array('hashids');